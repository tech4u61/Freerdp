## Disala-RustDesk-Windows-10-RDP-🇱🇰 

# Read This Before Rushing To Actions Tab 💀

* Note : make suer to install [RustDesk](https://rustdesk.com/) in your device.
* Note : i'm not responsible for suspended accounts
* Note : 30 miniute github timelimit bypassed now its 6 hours
* Note : Lower timelimit if u want to save ur github account (to 4 hours)

### Windows 10 Least

VM features:
- 2-core vCPU
- 7 GB RAM
- 100 GB Disk **(Excluded System Used)**
* We Have Some Cool Features That Other Scripts Dosen't Have
  - Automatically Telegram Installed
  - Automatically Winrar Installed
  - Automatically Open Bullet Installed
  - Automatically VM Quick Config Installed and Configuerd
  - Small Taskbar
  - Removed Stupid/Unrated Softwares
  - YT Watchtime Hack Cheat
  - Automatically Qbit Installed 
  - Ect ...

## Deploy and Run
<details>
    <summary>Windows 10 RDP Install and Run</summary>
<br>

* Note: Don't Make Github RDPs with personal account, [Github Unlimited Accounts Method](https://youtu.be/b-hDeGpPLhY).
  
* Go to [**Here**](https://thedisala.blogspot.com/2023/07/how-to-create-free-windows-10-rdp-using.html) and download the **Windows 10 - Rustdesk.yml**. (workflows file is on telegram channel, sub to me if u want)
    
* Create new github repo , click **create new file** and copy this text **.github/workflows/test** also type test in empty box and click **committed changes** after that **upload Windows 10 - RustDesk.yml in there**.
    
* Now go to **Actions** Tab and select one of system workflow.

* Click **Run Workflow** button on the left of **This workflow has a workflow_dispatch event trigger** line.

* Wait until a few minutes.

* Copy the **RustDesk ID** and Open RustDesk.exe and paste your ID in there and press enter then Give Password As **Disalardp1**

* Again Press Enter. **(Note: Don't Close Any Ongoing Tabs In Taskbar)

* Enjoy!

</details>

#You need proof just goto Action Tab And Watch....

# [Watch Tutorial If You Dosen't Understand This.](https://youtu.be/u3hHCQPACmY)

### Brought To You By Disala 💀 , Its Functional 😗.
### You Can See ID , Pass And Cool Ascki Art 
